Contact Service Project for Tori Bates

Files included:
- Contact.java
- ContactService.java
- ContactTest.java
- ContactServiceTest.java

Personalization:
The sample contact names and IDs were written using Tori Bates so the project feels more like your own work.

Suggested folder setup in Codio:
src/
  Contact.java
  ContactService.java

test/
  ContactTest.java
  ContactServiceTest.java
