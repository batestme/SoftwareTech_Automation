import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class ContactTest {

    @Test
    public void testValidContactCreation() {
        Contact contact = new Contact("TB1001", "Tori", "Bates", "8325551234", "15 Bayou Street");
        assertEquals("TB1001", contact.getContactId());
        assertEquals("Tori", contact.getFirstName());
        assertEquals("Bates", contact.getLastName());
        assertEquals("8325551234", contact.getPhone());
        assertEquals("15 Bayou Street", contact.getAddress());
    }

    @Test
    public void testContactIdTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("TB123456789", "Tori", "Bates", "8325551234", "15 Bayou Street");
        });
    }

    @Test
    public void testNullContactId() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact(null, "Tori", "Bates", "8325551234", "15 Bayou Street");
        });
    }

    @Test
    public void testFirstNameTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("TB1001", "TorianaLee", "Bates", "8325551234", "15 Bayou Street");
        });
    }

    @Test
    public void testNullFirstName() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("TB1001", null, "Bates", "8325551234", "15 Bayou Street");
        });
    }

    @Test
    public void testLastNameTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("TB1001", "Tori", "BatesSmithX", "8325551234", "15 Bayou Street");
        });
    }

    @Test
    public void testNullLastName() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("TB1001", "Tori", null, "8325551234", "15 Bayou Street");
        });
    }

    @Test
    public void testPhoneMustBeExactlyTenDigits() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("TB1001", "Tori", "Bates", "83255", "15 Bayou Street");
        });
    }

    @Test
    public void testPhoneCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("TB1001", "Tori", "Bates", null, "15 Bayou Street");
        });
    }

    @Test
    public void testAddressTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("TB1001", "Tori", "Bates", "8325551234",
                    "1234567890123456789012345678901");
        });
    }

    @Test
    public void testAddressCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("TB1001", "Tori", "Bates", "8325551234", null);
        });
    }

    @Test
    public void testSetFirstName() {
        Contact contact = new Contact("TB1001", "Tori", "Bates", "8325551234", "15 Bayou Street");
        contact.setFirstName("Victoria");
        assertEquals("Victoria", contact.getFirstName());
    }

    @Test
    public void testSetLastName() {
        Contact contact = new Contact("TB1001", "Tori", "Bates", "8325551234", "15 Bayou Street");
        contact.setLastName("Bryant");
        assertEquals("Bryant", contact.getLastName());
    }

    @Test
    public void testSetPhone() {
        Contact contact = new Contact("TB1001", "Tori", "Bates", "8325551234", "15 Bayou Street");
        contact.setPhone("7135559876");
        assertEquals("7135559876", contact.getPhone());
    }

    @Test
    public void testSetAddress() {
        Contact contact = new Contact("TB1001", "Tori", "Bates", "8325551234", "15 Bayou Street");
        contact.setAddress("22 Magnolia Avenue");
        assertEquals("22 Magnolia Avenue", contact.getAddress());
    }
}
