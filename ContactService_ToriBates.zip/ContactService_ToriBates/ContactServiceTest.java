import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class ContactServiceTest {

    @Test
    public void testAddContact() {
        ContactService service = new ContactService();
        Contact contact = new Contact("TB1001", "Tori", "Bates", "8325551234", "15 Bayou Street");

        service.addContact(contact);

        assertEquals("Tori", service.getContact("TB1001").getFirstName());
    }

    @Test
    public void testAddDuplicateContactId() {
        ContactService service = new ContactService();
        Contact contact1 = new Contact("TB1001", "Tori", "Bates", "8325551234", "15 Bayou Street");
        Contact contact2 = new Contact("TB1001", "Tori", "Bryant", "7135559876", "22 Magnolia Avenue");

        service.addContact(contact1);

        assertThrows(IllegalArgumentException.class, () -> {
            service.addContact(contact2);
        });
    }

    @Test
    public void testDeleteContact() {
        ContactService service = new ContactService();
        Contact contact = new Contact("TB1001", "Tori", "Bates", "8325551234", "15 Bayou Street");

        service.addContact(contact);
        service.deleteContact("TB1001");

        assertThrows(IllegalArgumentException.class, () -> {
            service.getContact("TB1001");
        });
    }

    @Test
    public void testUpdateFirstName() {
        ContactService service = new ContactService();
        Contact contact = new Contact("TB1001", "Tori", "Bates", "8325551234", "15 Bayou Street");

        service.addContact(contact);
        service.updateFirstName("TB1001", "Victoria");

        assertEquals("Victoria", service.getContact("TB1001").getFirstName());
    }

    @Test
    public void testUpdateLastName() {
        ContactService service = new ContactService();
        Contact contact = new Contact("TB1001", "Tori", "Bates", "8325551234", "15 Bayou Street");

        service.addContact(contact);
        service.updateLastName("TB1001", "Bryant");

        assertEquals("Bryant", service.getContact("TB1001").getLastName());
    }

    @Test
    public void testUpdatePhone() {
        ContactService service = new ContactService();
        Contact contact = new Contact("TB1001", "Tori", "Bates", "8325551234", "15 Bayou Street");

        service.addContact(contact);
        service.updatePhone("TB1001", "7135559876");

        assertEquals("7135559876", service.getContact("TB1001").getPhone());
    }

    @Test
    public void testUpdateAddress() {
        ContactService service = new ContactService();
        Contact contact = new Contact("TB1001", "Tori", "Bates", "8325551234", "15 Bayou Street");

        service.addContact(contact);
        service.updateAddress("TB1001", "22 Magnolia Avenue");

        assertEquals("22 Magnolia Avenue", service.getContact("TB1001").getAddress());
    }

    @Test
    public void testDeleteNonexistentContact() {
        ContactService service = new ContactService();

        assertThrows(IllegalArgumentException.class, () -> {
            service.deleteContact("TB9999");
        });
    }

    @Test
    public void testUpdateNonexistentContact() {
        ContactService service = new ContactService();

        assertThrows(IllegalArgumentException.class, () -> {
            service.updateFirstName("TB9999", "Victoria");
        });
    }
}
